(function() {
  $('.datepicker').datepicker();

}).call(this);
